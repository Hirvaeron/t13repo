import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SzavazatokTablazatComponent } from './szavazatok-tablazat.component';
import { FormsModule } from '@angular/forms';
import { By } from "@angular/platform-browser"

describe('SzavazatokTablazatComponent', () => {
  let component: SzavazatokTablazatComponent;
  let fixture: ComponentFixture<SzavazatokTablazatComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [SzavazatokTablazatComponent],
      imports: [FormsModule]
    })
      .compileComponents();

    fixture = TestBed.createComponent(SzavazatokTablazatComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it("korzetErtek mező adatkötés tesztje", () => {
    const input = fixture.debugElement.query(By.css("#korzet")).nativeElement;
    input.value = "8";
    input.dispatchEvent(new Event("input"));
    expect(component.korzetErtek).toBe(8)
  })

  it("Összes adat mennyisége üres adat esetén", () => {
    component.keresoErtek = "";
    expect(component.szurtElemek.length).toBe(40)
  })

  it("Összes adat mennyisége HEP adat esetén", () => {
    component.keresoErtek = "HEP";
    expect(component.szurtElemek.length).toBe(8)
  })
});
