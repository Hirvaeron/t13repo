import { Component } from '@angular/core';

@Component({
  selector: 'app-feladat',
  templateUrl: './feladat.component.html',
  styleUrl: './feladat.component.css'
})
export class FeladatComponent {
  eredmenyek: string[] = [];
  EredmenyMentes() {
    this.eredmenyek.push(`${this.PrimE(this.vizsgaltSzam)}`)
  }
  vizsgaltSzam: number = 1;
  PrimE(vizsgaltSzam: number): string {
    let oszto: number = 0;
    for (let i: number = 0; i <= vizsgaltSzam; i++) {
      if (vizsgaltSzam % i == 0) {
        oszto++;
      }
    }
    if (oszto == 2) {
      return `A(z) ${vizsgaltSzam} prím szám!`;
    } else {
      return `A(z) ${vizsgaltSzam} NEM prím szám!`;
    }
  }
}
